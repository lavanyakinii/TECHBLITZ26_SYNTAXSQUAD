import { NavLink, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { motion } from 'framer-motion';
import {
  LayoutDashboard, CalendarDays, CalendarPlus, BarChart3,
  LogOut, Stethoscope, MessageSquare, Users
} from 'lucide-react';

const navItems = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['doctor', 'receptionist', 'admin'] },
  { to: '/appointments', label: 'Appointments', icon: CalendarDays, roles: ['doctor', 'receptionist', 'admin'] },
  { to: '/book', label: 'Book New', icon: CalendarPlus, roles: ['receptionist', 'admin'] },
  { to: '/calendar', label: 'Calendar', icon: CalendarDays, roles: ['doctor', 'receptionist', 'admin'] },
  { to: '/patients', label: 'Patients', icon: Users, roles: ['doctor', 'receptionist', 'admin'] },
  { to: '/analytics', label: 'Analytics', icon: BarChart3, roles: ['admin', 'doctor'] },
];

export default function AppSidebar() {
  const { user, logout } = useAuth();
  const location = useLocation();

  const filteredNav = navItems.filter(item => user && item.roles.includes(user.role));

  return (
    <motion.aside
      initial={{ x: -240 }}
      animate={{ x: 0 }}
      transition={{ type: 'spring', stiffness: 200, damping: 25 }}
      className="sidebar-nav w-60 flex flex-col border-r border-border shrink-0"
    >
      <div className="p-5 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 gradient-primary rounded-xl flex items-center justify-center">
            <Stethoscope className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h2 className="font-heading font-bold text-sm text-foreground">Smart Clinic</h2>
            <p className="text-xs text-muted-foreground capitalize">{user?.role}</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-3 space-y-1">
        {filteredNav.map(item => {
          const isActive = location.pathname === item.to;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all
                ${isActive
                  ? 'bg-primary/10 text-primary'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                }`}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </NavLink>
          );
        })}
      </nav>

      <div className="p-3 border-t border-border">
        <div className="flex items-center gap-3 px-3 py-2 mb-2">
          <div className="w-8 h-8 gradient-accent rounded-full flex items-center justify-center text-accent-foreground text-xs font-bold">
            {user?.name?.charAt(0)}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground truncate">{user?.name}</p>
            <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
          </div>
        </div>
        <button
          onClick={logout}
          className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-destructive hover:bg-destructive/10 transition-all w-full"
        >
          <LogOut className="w-4 h-4" /> Sign Out
        </button>
      </div>
    </motion.aside>
  );
}
