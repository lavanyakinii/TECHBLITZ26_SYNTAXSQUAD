import { motion } from 'framer-motion';
import { Appointment } from '@/types/clinic';
import { useAppointments } from '@/contexts/AppointmentContext';
import { Clock, Phone, AlertTriangle, CheckCircle, XCircle, MoreHorizontal } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';

const statusConfig = {
  scheduled: { label: 'Scheduled', class: 'bg-info/10 text-info border-info/20' },
  completed: { label: 'Completed', class: 'bg-success/10 text-success border-success/20' },
  cancelled: { label: 'Cancelled', class: 'bg-destructive/10 text-destructive border-destructive/20' },
  'no-show': { label: 'No-show', class: 'bg-warning/10 text-warning border-warning/20' },
};

export default function AppointmentCard({ appointment, index = 0 }: { appointment: Appointment; index?: number }) {
  const { cancelAppointment, updateStatus } = useAppointments();
  const status = statusConfig[appointment.status];
  const highRisk = (appointment.noShowProbability ?? 0) > 0.5;

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      className="glass-card p-4 flex items-center gap-4 group"
    >
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <p className="font-medium text-foreground text-sm">{appointment.patientName}</p>
          <Badge variant="outline" className={status.class}>{status.label}</Badge>
          {highRisk && appointment.status === 'scheduled' && (
            <span className="flex items-center gap-1 text-xs text-warning">
              <AlertTriangle className="w-3 h-3" /> High no-show risk
            </span>
          )}
        </div>
        <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
          <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {appointment.time}</span>
          <span className="flex items-center gap-1"><Phone className="w-3 h-3" /> {appointment.patientPhone}</span>
          <span>{appointment.symptoms}</span>
        </div>
      </div>

      <div className="flex items-center gap-1 text-muted-foreground">
        <span className="text-xs">{appointment.doctorName}</span>
      </div>

      {appointment.status === 'scheduled' && (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity">
              <MoreHorizontal className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => updateStatus(appointment.id, 'completed')}>
              <CheckCircle className="w-4 h-4 mr-2 text-success" /> Mark Completed
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => cancelAppointment(appointment.id)}>
              <XCircle className="w-4 h-4 mr-2 text-destructive" /> Cancel
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => updateStatus(appointment.id, 'no-show')}>
              <AlertTriangle className="w-4 h-4 mr-2 text-warning" /> Mark No-show
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      )}
    </motion.div>
  );
}
