import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, X, Send, Bot, User } from 'lucide-react';
import { ChatMessage } from '@/types/clinic';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAppointments } from '@/contexts/AppointmentContext';
import { doctors, generateTimeSlots } from '@/data/clinicData';

export default function ChatBot() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: '1', role: 'assistant', content: "Hello! 👋 I'm your Smart Clinic AI assistant. I can help you:\n\n• **Book appointments**\n• **Check available slots**\n• **Cancel or reschedule**\n• **Answer clinic questions**\n\nHow can I help you today?", timestamp: new Date().toISOString() },
  ]);
  const [typing, setTyping] = useState(false);
  const { appointments, addAppointment } = useAppointments();

  const respond = (userMsg: string) => {
    const lower = userMsg.toLowerCase();
    let response = '';

    if (lower.includes('book') || lower.includes('appointment')) {
      response = "I'd love to help you book an appointment! 📅\n\nWe have the following doctors available:\n\n" +
        doctors.map((d, i) => `${i + 1}. **${d.name}** — ${d.specialty}`).join('\n') +
        "\n\nPlease tell me which doctor you'd like to see, along with your preferred date.";
    } else if (lower.includes('slot') || lower.includes('available') || lower.includes('time')) {
      const today = new Date().toISOString().split('T')[0];
      const slots = generateTimeSlots(doctors[0], today, appointments);
      const available = slots.filter(s => s.available).slice(0, 5);
      response = `Here are some available slots for **${doctors[0].name}** today:\n\n` +
        available.map(s => `• ${s.time}`).join('\n') +
        '\n\nWould you like to book any of these?';
    } else if (lower.includes('cancel')) {
      response = "To cancel an appointment, I'll need the patient name or appointment ID. You can also cancel from the Appointments page directly.";
    } else if (lower.includes('hour') || lower.includes('timing') || lower.includes('open')) {
      response = "🏥 **Clinic Hours:**\n\n" +
        doctors.map(d => `• **${d.name}**: ${d.workingHours.start} - ${d.workingHours.end}`).join('\n') +
        "\n\nWe're open Monday through Saturday!";
    } else if (lower.includes('help') || lower.includes('what can')) {
      response = "I can assist with:\n\n• 📅 **Booking** new appointments\n• 🔍 **Checking** available time slots\n• ❌ **Cancelling** appointments\n• 🔄 **Rescheduling** visits\n• ℹ️ **Clinic information** and hours\n\nJust type your request!";
    } else {
      response = "I understand you're asking about: *" + userMsg + "*\n\nCould you be more specific? Try asking about:\n• Booking an appointment\n• Available slots\n• Clinic hours\n• Cancellations";
    }
    return response;
  };

  const handleSend = () => {
    if (!input.trim()) return;
    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', content: input, timestamp: new Date().toISOString() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setTyping(true);

    setTimeout(() => {
      const response = respond(input);
      setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: 'assistant', content: response, timestamp: new Date().toISOString() }]);
      setTyping(false);
    }, 1000 + Math.random() * 500);
  };

  return (
    <>
      {/* Floating button */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setOpen(!open)}
        className="fixed bottom-6 right-6 w-14 h-14 gradient-primary rounded-full flex items-center justify-center shadow-lg z-50"
      >
        {open ? <X className="w-6 h-6 text-primary-foreground" /> : <MessageSquare className="w-6 h-6 text-primary-foreground" />}
      </motion.button>

      {/* Chat panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-24 right-6 w-96 h-[500px] glass-card-strong flex flex-col z-50 overflow-hidden"
          >
            {/* Header */}
            <div className="gradient-primary p-4 flex items-center gap-3">
              <div className="w-8 h-8 bg-primary-foreground/20 rounded-full flex items-center justify-center">
                <Bot className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <p className="text-sm font-semibold text-primary-foreground">AI Clinic Assistant</p>
                <p className="text-xs text-primary-foreground/70">Always online</p>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.map(msg => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex gap-2 ${msg.role === 'user' ? 'justify-end' : ''}`}
                >
                  {msg.role === 'assistant' && (
                    <div className="w-6 h-6 gradient-primary rounded-full flex items-center justify-center shrink-0 mt-1">
                      <Bot className="w-3 h-3 text-primary-foreground" />
                    </div>
                  )}
                  <div className={`max-w-[80%] rounded-xl px-3 py-2 text-sm whitespace-pre-line
                    ${msg.role === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted text-foreground'
                    }`}
                  >
                    {msg.content}
                  </div>
                </motion.div>
              ))}
              {typing && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-2 items-center">
                  <div className="w-6 h-6 gradient-primary rounded-full flex items-center justify-center shrink-0">
                    <Bot className="w-3 h-3 text-primary-foreground" />
                  </div>
                  <div className="bg-muted rounded-xl px-4 py-2 flex gap-1">
                    <span className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </motion.div>
              )}
            </div>

            {/* Input */}
            <div className="p-3 border-t border-border flex gap-2">
              <Input
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSend()}
                placeholder="Type a message..."
                className="text-sm"
              />
              <Button size="icon" onClick={handleSend} className="gradient-primary border-0 shrink-0">
                <Send className="w-4 h-4 text-primary-foreground" />
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
