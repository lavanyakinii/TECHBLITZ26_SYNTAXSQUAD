import React, { createContext, useContext, useState, useCallback } from 'react';
import { Appointment } from '@/types/clinic';
import { initialAppointments, predictNoShow, patients } from '@/data/clinicData';

interface AppointmentContextType {
  appointments: Appointment[];
  addAppointment: (appt: Omit<Appointment, 'id' | 'createdAt' | 'noShowProbability'>) => Appointment;
  cancelAppointment: (id: string) => void;
  updateStatus: (id: string, status: Appointment['status']) => void;
  rescheduleAppointment: (id: string, newDate: string, newTime: string) => void;
}

const AppointmentContext = createContext<AppointmentContextType | null>(null);

export function AppointmentProvider({ children }: { children: React.ReactNode }) {
  const [appointments, setAppointments] = useState<Appointment[]>(initialAppointments);

  const addAppointment = useCallback((appt: Omit<Appointment, 'id' | 'createdAt' | 'noShowProbability'>) => {
    const patient = patients.find(p => p.phone === appt.patientPhone);
    const newAppt: Appointment = {
      ...appt,
      id: `a${Date.now()}`,
      createdAt: new Date().toISOString(),
      noShowProbability: predictNoShow(patient),
    };
    setAppointments(prev => [...prev, newAppt]);
    return newAppt;
  }, []);

  const cancelAppointment = useCallback((id: string) => {
    setAppointments(prev => prev.map(a => a.id === id ? { ...a, status: 'cancelled' } : a));
  }, []);

  const updateStatus = useCallback((id: string, status: Appointment['status']) => {
    setAppointments(prev => prev.map(a => a.id === id ? { ...a, status } : a));
  }, []);

  const rescheduleAppointment = useCallback((id: string, newDate: string, newTime: string) => {
    setAppointments(prev => prev.map(a => a.id === id ? { ...a, date: newDate, time: newTime } : a));
  }, []);

  return (
    <AppointmentContext.Provider value={{ appointments, addAppointment, cancelAppointment, updateStatus, rescheduleAppointment }}>
      {children}
    </AppointmentContext.Provider>
  );
}

export function useAppointments() {
  const ctx = useContext(AppointmentContext);
  if (!ctx) throw new Error('useAppointments must be used within AppointmentProvider');
  return ctx;
}
