import React, { createContext, useContext, useState, useCallback } from 'react';
import { User, UserRole } from '@/types/clinic';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string, role: UserRole) => boolean;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

const demoUsers: Record<UserRole, User> = {
  doctor: { id: 'u1', name: 'Dr. Priya Sharma', email: 'doctor@clinic.com', role: 'doctor' },
  receptionist: { id: 'u2', name: 'Riya Kapoor', email: 'reception@clinic.com', role: 'receptionist' },
  admin: { id: 'u3', name: 'Admin', email: 'admin@clinic.com', role: 'admin' },
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const login = useCallback((email: string, _password: string, role: UserRole) => {
    const demoUser = demoUsers[role];
    if (demoUser) {
      setUser({ ...demoUser, email });
      return true;
    }
    return false;
  }, []);

  const logout = useCallback(() => setUser(null), []);

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
