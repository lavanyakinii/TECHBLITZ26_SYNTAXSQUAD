import { Outlet } from 'react-router-dom';
import AppSidebar from '@/components/AppSidebar';
import ChatBot from '@/components/ChatBot';

export default function DashboardLayout() {
  return (
    <div className="flex h-screen overflow-hidden gradient-bg">
      <AppSidebar />
      <main className="flex-1 overflow-y-auto p-6">
        <Outlet />
      </main>
      <ChatBot />
    </div>
  );
}
