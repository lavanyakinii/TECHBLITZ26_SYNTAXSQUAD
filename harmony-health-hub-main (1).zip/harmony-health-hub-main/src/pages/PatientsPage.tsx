import { motion } from 'framer-motion';
import { patients } from '@/data/clinicData';
import { useAppointments } from '@/contexts/AppointmentContext';
import { User, Phone, Mail, AlertTriangle, CalendarDays } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function PatientsPage() {
  const { appointments } = useAppointments();

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-heading font-bold text-foreground">Patients</h1>
        <p className="text-muted-foreground text-sm">Patient records and history</p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {patients.map((patient, i) => {
          const patientAppts = appointments.filter(a => a.patientPhone === patient.phone);
          const highRisk = patient.noShowCount / Math.max(patient.totalAppointments, 1) > 0.3;

          return (
            <motion.div
              key={patient.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="glass-card p-5 space-y-3"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 gradient-primary rounded-full flex items-center justify-center text-primary-foreground font-bold text-sm">
                    {patient.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{patient.name}</p>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                      <span className="flex items-center gap-1"><Phone className="w-3 h-3" /> {patient.phone}</span>
                      {patient.email && <span className="flex items-center gap-1"><Mail className="w-3 h-3" /> {patient.email}</span>}
                    </div>
                  </div>
                </div>
                {highRisk && (
                  <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20 text-xs">
                    <AlertTriangle className="w-3 h-3 mr-1" /> High risk
                  </Badge>
                )}
              </div>

              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><CalendarDays className="w-3 h-3" /> {patient.totalAppointments} visits</span>
                <span>No-shows: {patient.noShowCount}</span>
              </div>

              <div className="flex flex-wrap gap-1">
                {patient.history.map(h => (
                  <Badge key={h} variant="secondary" className="text-xs">{h}</Badge>
                ))}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
