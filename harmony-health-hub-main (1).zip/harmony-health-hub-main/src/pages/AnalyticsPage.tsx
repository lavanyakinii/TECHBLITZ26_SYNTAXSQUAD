import { motion } from 'framer-motion';
import { useAppointments } from '@/contexts/AppointmentContext';
import { getAnalyticsData, doctors } from '@/data/clinicData';
import StatsCard from '@/components/StatsCard';
import { BarChart3, TrendingDown, UserX, DollarSign, Users, CalendarDays } from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, Legend, RadialBarChart, RadialBar
} from 'recharts';

const COLORS = ['hsl(199,89%,48%)', 'hsl(152,69%,46%)', 'hsl(0,84%,60%)', 'hsl(38,92%,50%)'];

export default function AnalyticsPage() {
  const { appointments } = useAppointments();
  const analytics = getAnalyticsData(appointments);

  const doctorWorkloadData = analytics.doctorWorkload.map((d, i) => ({
    ...d,
    fill: COLORS[i % COLORS.length],
  }));

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-heading font-bold text-foreground flex items-center gap-2">
          <BarChart3 className="w-6 h-6 text-primary" /> Analytics Dashboard
        </h1>
        <p className="text-muted-foreground text-sm">Comprehensive clinic performance insights</p>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard title="Total Appointments" value={appointments.length} icon={CalendarDays} gradient="primary" />
        <StatsCard title="Cancellation Rate" value={`${analytics.cancellationRate}%`} icon={TrendingDown} gradient="accent" />
        <StatsCard title="No-show Rate" value={`${analytics.noShowRate}%`} icon={UserX} gradient="warning" />
        <StatsCard title="Revenue" value={`₹${analytics.totalRevenue}`} icon={DollarSign} gradient="success" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass-card p-5">
          <h3 className="text-sm font-heading font-semibold text-foreground mb-4">Weekly Trend</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={analytics.dailyAppointments}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(214,20%,90%)" />
              <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="hsl(215,15%,50%)" />
              <YAxis tick={{ fontSize: 12 }} stroke="hsl(215,15%,50%)" />
              <Tooltip contentStyle={{ borderRadius: 12, border: 'none', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }} />
              <Line type="monotone" dataKey="count" stroke="hsl(199,89%,48%)" strokeWidth={2.5} dot={{ r: 4, fill: 'hsl(199,89%,48%)' }} />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass-card p-5">
          <h3 className="text-sm font-heading font-semibold text-foreground mb-4">Doctor Workload</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={analytics.doctorWorkload} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(214,20%,90%)" />
              <XAxis type="number" tick={{ fontSize: 12 }} stroke="hsl(215,15%,50%)" />
              <YAxis dataKey="name" type="category" width={80} tick={{ fontSize: 11 }} stroke="hsl(215,15%,50%)" />
              <Tooltip contentStyle={{ borderRadius: 12, border: 'none', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }} />
              <Bar dataKey="appointments" fill="hsl(260,67%,60%)" radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="glass-card p-5">
          <h3 className="text-sm font-heading font-semibold text-foreground mb-4">Status Breakdown</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={analytics.statusDistribution} dataKey="count" nameKey="status" cx="50%" cy="50%" outerRadius={90} innerRadius={50} paddingAngle={3}>
                {analytics.statusDistribution.map((_, i) => (
                  <Cell key={i} fill={COLORS[i]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="glass-card p-5">
          <h3 className="text-sm font-heading font-semibold text-foreground mb-4">No-show Risk Analysis</h3>
          <div className="space-y-3">
            {appointments.filter(a => a.status === 'scheduled').sort((a, b) => (b.noShowProbability ?? 0) - (a.noShowProbability ?? 0)).slice(0, 5).map(a => (
              <div key={a.id} className="flex items-center gap-3">
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">{a.patientName}</p>
                  <p className="text-xs text-muted-foreground">{a.date} at {a.time}</p>
                </div>
                <div className="w-24">
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${(a.noShowProbability ?? 0) * 100}%`,
                        background: (a.noShowProbability ?? 0) > 0.5 ? 'hsl(0,84%,60%)' : (a.noShowProbability ?? 0) > 0.3 ? 'hsl(38,92%,50%)' : 'hsl(152,69%,46%)',
                      }}
                    />
                  </div>
                </div>
                <span className="text-xs font-medium text-foreground w-10 text-right">
                  {Math.round((a.noShowProbability ?? 0) * 100)}%
                </span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
