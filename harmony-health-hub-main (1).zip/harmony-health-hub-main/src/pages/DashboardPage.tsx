import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { useAppointments } from '@/contexts/AppointmentContext';
import { getAnalyticsData } from '@/data/clinicData';
import StatsCard from '@/components/StatsCard';
import AppointmentCard from '@/components/AppointmentCard';
import { CalendarDays, Users, TrendingUp, AlertTriangle, Clock, DollarSign } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const COLORS = ['hsl(199,89%,48%)', 'hsl(152,69%,46%)', 'hsl(0,84%,60%)', 'hsl(38,92%,50%)'];

export default function DashboardPage() {
  const { user } = useAuth();
  const { appointments } = useAppointments();
  const analytics = getAnalyticsData(appointments);
  const todayAppointments = appointments.filter(a => a.date === new Date().toISOString().split('T')[0]);
  const scheduled = todayAppointments.filter(a => a.status === 'scheduled');

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-heading font-bold text-foreground">
          Welcome back, {user?.name?.split(' ')[0]} 👋
        </h1>
        <p className="text-muted-foreground text-sm">Here's what's happening at your clinic today</p>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard title="Today's Appointments" value={todayAppointments.length} icon={CalendarDays} trend={{ value: 12, positive: true }} gradient="primary" />
        <StatsCard title="Patients Waiting" value={scheduled.length} icon={Clock} subtitle="In queue" gradient="accent" />
        <StatsCard title="Total Patients" value={analytics.totalPatients} icon={Users} trend={{ value: 8, positive: true }} gradient="success" />
        <StatsCard title="Revenue Today" value={`₹${analytics.totalRevenue}`} icon={DollarSign} trend={{ value: 5, positive: true }} gradient="warning" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass-card p-5 lg:col-span-2">
          <h3 className="text-sm font-heading font-semibold text-foreground mb-4">Weekly Appointments</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={analytics.dailyAppointments}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(214,20%,90%)" />
              <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="hsl(215,15%,50%)" />
              <YAxis tick={{ fontSize: 12 }} stroke="hsl(215,15%,50%)" />
              <Tooltip contentStyle={{ borderRadius: 12, border: 'none', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }} />
              <Bar dataKey="count" fill="hsl(199,89%,48%)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Pie */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="glass-card p-5">
          <h3 className="text-sm font-heading font-semibold text-foreground mb-4">Status Distribution</h3>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={analytics.statusDistribution} dataKey="count" nameKey="status" cx="50%" cy="50%" outerRadius={70} innerRadius={40}>
                {analytics.statusDistribution.map((_, i) => (
                  <Cell key={i} fill={COLORS[i % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex flex-wrap gap-3 mt-2 justify-center">
            {analytics.statusDistribution.map((item, i) => (
              <span key={item.status} className="flex items-center gap-1 text-xs text-muted-foreground">
                <span className="w-2 h-2 rounded-full" style={{ background: COLORS[i] }} />
                {item.status}
              </span>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Today's appointments */}
      <div>
        <h3 className="text-sm font-heading font-semibold text-foreground mb-3">Today's Appointments</h3>
        <div className="space-y-2">
          {todayAppointments.length === 0 ? (
            <div className="glass-card p-8 text-center text-muted-foreground">No appointments today</div>
          ) : (
            todayAppointments.map((appt, i) => <AppointmentCard key={appt.id} appointment={appt} index={i} />)
          )}
        </div>
      </div>
    </div>
  );
}
