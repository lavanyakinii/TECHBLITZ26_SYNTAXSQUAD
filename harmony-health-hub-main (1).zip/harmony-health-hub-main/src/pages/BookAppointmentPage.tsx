import { useState } from 'react';
import { motion } from 'framer-motion';
import { useAppointments } from '@/contexts/AppointmentContext';
import { doctors, generateTimeSlots } from '@/data/clinicData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { CalendarPlus, Clock, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function BookAppointmentPage() {
  const { appointments, addAppointment } = useAppointments();
  const [form, setForm] = useState({ patientName: '', patientPhone: '', doctorId: '', date: '', time: '', symptoms: '' });
  const [selectedDoctor, setSelectedDoctor] = useState(doctors[0]);
  const [booked, setBooked] = useState(false);

  const today = new Date().toISOString().split('T')[0];
  const slots = form.doctorId
    ? generateTimeSlots(doctors.find(d => d.id === form.doctorId) || doctors[0], form.date || today, appointments)
    : [];

  const handleDoctorChange = (id: string) => {
    setForm(prev => ({ ...prev, doctorId: id, time: '' }));
    setSelectedDoctor(doctors.find(d => d.id === id) || doctors[0]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.patientName || !form.patientPhone || !form.doctorId || !form.date || !form.time) {
      toast.error('Please fill all required fields');
      return;
    }
    const doctor = doctors.find(d => d.id === form.doctorId)!;
    addAppointment({
      ...form,
      doctorName: doctor.name,
      status: 'scheduled',
    });
    setBooked(true);
    toast.success('Appointment booked successfully!');
    setTimeout(() => {
      setBooked(false);
      setForm({ patientName: '', patientPhone: '', doctorId: '', date: '', time: '', symptoms: '' });
    }, 2000);
  };

  if (booked) {
    return (
      <div className="flex items-center justify-center h-full">
        <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="glass-card p-12 text-center">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.2, type: 'spring' }} className="w-20 h-20 bg-success rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-success-foreground" />
          </motion.div>
          <h2 className="text-xl font-heading font-bold text-foreground">Appointment Booked!</h2>
          <p className="text-muted-foreground text-sm mt-2">Confirmation has been sent to the patient</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-heading font-bold text-foreground flex items-center gap-2">
          <CalendarPlus className="w-6 h-6 text-primary" /> Book Appointment
        </h1>
        <p className="text-muted-foreground text-sm">Schedule a new patient appointment</p>
      </motion.div>

      <motion.form initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} onSubmit={handleSubmit} className="glass-card p-6 space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium text-foreground mb-1 block">Patient Name *</label>
            <Input value={form.patientName} onChange={e => setForm(p => ({ ...p, patientName: e.target.value }))} placeholder="Enter patient name" />
          </div>
          <div>
            <label className="text-sm font-medium text-foreground mb-1 block">Phone Number *</label>
            <Input value={form.patientPhone} onChange={e => setForm(p => ({ ...p, patientPhone: e.target.value }))} placeholder="Enter phone number" />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium text-foreground mb-1 block">Select Doctor *</label>
            <Select value={form.doctorId} onValueChange={handleDoctorChange}>
              <SelectTrigger><SelectValue placeholder="Choose doctor" /></SelectTrigger>
              <SelectContent>
                {doctors.map(d => (
                  <SelectItem key={d.id} value={d.id}>{d.name} — {d.specialty}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm font-medium text-foreground mb-1 block">Date *</label>
            <Input type="date" value={form.date} min={today} onChange={e => setForm(p => ({ ...p, date: e.target.value, time: '' }))} />
          </div>
        </div>

        {/* Time slots */}
        {form.doctorId && form.date && (
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block flex items-center gap-1">
              <Clock className="w-4 h-4" /> Available Slots
            </label>
            <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
              {slots.map(slot => (
                <motion.button
                  key={slot.time}
                  type="button"
                  whileHover={{ scale: slot.available ? 1.05 : 1 }}
                  whileTap={{ scale: slot.available ? 0.95 : 1 }}
                  onClick={() => slot.available && setForm(p => ({ ...p, time: slot.time }))}
                  disabled={!slot.available}
                  className={`py-2 px-1 rounded-lg text-xs font-medium border transition-all
                    ${form.time === slot.time
                      ? 'bg-primary text-primary-foreground border-primary'
                      : slot.available
                        ? 'border-border text-foreground hover:border-primary/50'
                        : 'border-border text-muted-foreground/40 bg-muted/50 cursor-not-allowed line-through'
                    }`}
                >
                  {slot.time}
                </motion.button>
              ))}
            </div>
          </div>
        )}

        <div>
          <label className="text-sm font-medium text-foreground mb-1 block">Symptoms</label>
          <Textarea value={form.symptoms} onChange={e => setForm(p => ({ ...p, symptoms: e.target.value }))} placeholder="Describe symptoms..." rows={3} />
        </div>

        <Button type="submit" className="w-full gradient-primary text-primary-foreground border-0" size="lg">
          Book Appointment
        </Button>
      </motion.form>
    </div>
  );
}
