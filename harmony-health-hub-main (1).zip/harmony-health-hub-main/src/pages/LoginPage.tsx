import { motion } from 'framer-motion';
import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { UserRole } from '@/types/clinic';
import { Stethoscope, UserCog, ShieldCheck, LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const roles: { role: UserRole; label: string; icon: React.ReactNode; description: string }[] = [
  { role: 'doctor', label: 'Doctor', icon: <Stethoscope className="w-6 h-6" />, description: 'Access patient queue & schedule' },
  { role: 'receptionist', label: 'Receptionist', icon: <UserCog className="w-6 h-6" />, description: 'Manage appointments & patients' },
  { role: 'admin', label: 'Admin', icon: <ShieldCheck className="w-6 h-6" />, description: 'Full system access & analytics' },
];

export default function LoginPage() {
  const { login } = useAuth();
  const [selectedRole, setSelectedRole] = useState<UserRole>('receptionist');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please fill in all fields');
      return;
    }
    const success = login(email, password, selectedRole);
    if (!success) setError('Invalid credentials');
  };

  return (
    <div className="page-container flex items-center justify-center min-h-screen p-4 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute top-20 left-20 w-72 h-72 rounded-full bg-primary/10 blur-3xl animate-float" />
      <div className="absolute bottom-20 right-20 w-96 h-96 rounded-full bg-accent/10 blur-3xl animate-float" style={{ animationDelay: '2s' }} />
      <div className="absolute top-1/2 left-1/2 w-64 h-64 rounded-full bg-secondary/10 blur-3xl animate-float" style={{ animationDelay: '4s' }} />

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="glass-card-strong w-full max-w-md p-8 relative z-10"
      >
        <div className="text-center mb-8">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 200, delay: 0.2 }}
            className="w-16 h-16 gradient-primary rounded-2xl flex items-center justify-center mx-auto mb-4"
          >
            <Stethoscope className="w-8 h-8 text-primary-foreground" />
          </motion.div>
          <h1 className="text-2xl font-heading font-bold text-foreground">Smart Clinic</h1>
          <p className="text-muted-foreground text-sm mt-1">AI-Powered Appointment & Management System</p>
        </div>

        {/* Role Selection */}
        <div className="grid grid-cols-3 gap-2 mb-6">
          {roles.map(({ role, label, icon }) => (
            <motion.button
              key={role}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => setSelectedRole(role)}
              className={`flex flex-col items-center gap-1 p-3 rounded-lg border transition-all text-sm
                ${selectedRole === role
                  ? 'bg-primary/10 border-primary text-primary'
                  : 'border-border text-muted-foreground hover:border-primary/30'
                }`}
            >
              {icon}
              <span className="font-medium">{label}</span>
            </motion.button>
          ))}
        </div>

        <p className="text-xs text-center text-muted-foreground mb-4">
          {roles.find(r => r.role === selectedRole)?.description}
        </p>

        <form onSubmit={handleLogin} className="space-y-4">
          <Input
            type="email"
            placeholder="Email address"
            value={email}
            onChange={e => { setEmail(e.target.value); setError(''); }}
          />
          <Input
            type="password"
            placeholder="Password"
            value={password}
            onChange={e => { setPassword(e.target.value); setError(''); }}
          />
          {error && <p className="text-destructive text-xs text-center">{error}</p>}
          <Button type="submit" className="w-full gradient-primary text-primary-foreground border-0">
            <LogIn className="w-4 h-4 mr-2" /> Sign In as {roles.find(r => r.role === selectedRole)?.label}
          </Button>
        </form>

        <p className="text-xs text-muted-foreground text-center mt-4">
          Demo: Use any email & password to login
        </p>
      </motion.div>
    </div>
  );
}
