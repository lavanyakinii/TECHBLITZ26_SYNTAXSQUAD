import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { useAppointments } from '@/contexts/AppointmentContext';
import { doctors } from '@/data/clinicData';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const statusColors: Record<string, string> = {
  scheduled: 'bg-info/20 text-info border-info/30',
  completed: 'bg-success/20 text-success border-success/30',
  cancelled: 'bg-destructive/20 text-destructive border-destructive/30',
  'no-show': 'bg-warning/20 text-warning border-warning/30',
};

export default function CalendarPage() {
  const { appointments } = useAppointments();
  const [currentDate, setCurrentDate] = useState(new Date());

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const days = useMemo(() => {
    const arr: (number | null)[] = Array(firstDay).fill(null);
    for (let i = 1; i <= daysInMonth; i++) arr.push(i);
    return arr;
  }, [firstDay, daysInMonth]);

  const getAppointmentsForDay = (day: number) => {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return appointments.filter(a => a.date === dateStr);
  };

  const today = new Date();
  const isToday = (day: number) => day === today.getDate() && month === today.getMonth() && year === today.getFullYear();

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-heading font-bold text-foreground">Calendar</h1>
        <p className="text-muted-foreground text-sm">View appointments schedule</p>
      </motion.div>

      <div className="glass-card p-5">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <Button variant="ghost" size="icon" onClick={() => setCurrentDate(new Date(year, month - 1))}>
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h2 className="font-heading font-semibold text-foreground">
            {currentDate.toLocaleDateString('en', { month: 'long', year: 'numeric' })}
          </h2>
          <Button variant="ghost" size="icon" onClick={() => setCurrentDate(new Date(year, month + 1))}>
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>

        {/* Weekday headers */}
        <div className="grid grid-cols-7 gap-1 mb-1">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
            <div key={d} className="text-center text-xs font-medium text-muted-foreground py-2">{d}</div>
          ))}
        </div>

        {/* Days grid */}
        <div className="grid grid-cols-7 gap-1">
          {days.map((day, i) => {
            if (day === null) return <div key={`empty-${i}`} />;
            const dayAppointments = getAppointmentsForDay(day);
            return (
              <motion.div
                key={day}
                whileHover={{ scale: 1.02 }}
                className={`min-h-[80px] p-1.5 rounded-lg border transition-all cursor-default
                  ${isToday(day) ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/30'}`}
              >
                <span className={`text-xs font-medium ${isToday(day) ? 'text-primary' : 'text-foreground'}`}>{day}</span>
                <div className="space-y-0.5 mt-1">
                  {dayAppointments.slice(0, 3).map(a => (
                    <div key={a.id} className={`text-[10px] px-1 py-0.5 rounded truncate border ${statusColors[a.status]}`}>
                      {a.time} {a.patientName.split(' ')[0]}
                    </div>
                  ))}
                  {dayAppointments.length > 3 && (
                    <span className="text-[10px] text-muted-foreground">+{dayAppointments.length - 3} more</span>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
