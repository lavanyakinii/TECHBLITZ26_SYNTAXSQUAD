export type UserRole = 'doctor' | 'receptionist' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
}

export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  avatar?: string;
  workingHours: { start: string; end: string };
  breakTime: { start: string; end: string };
  consultationDuration: number; // minutes
}

export interface Patient {
  id: string;
  name: string;
  phone: string;
  email?: string;
  history: string[];
  noShowCount: number;
  totalAppointments: number;
}

export interface TimeSlot {
  time: string;
  available: boolean;
}

export interface Appointment {
  id: string;
  patientName: string;
  patientPhone: string;
  doctorId: string;
  doctorName: string;
  date: string;
  time: string;
  symptoms: string;
  status: 'scheduled' | 'completed' | 'cancelled' | 'no-show';
  noShowProbability?: number;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface AnalyticsData {
  dailyAppointments: { date: string; count: number }[];
  doctorWorkload: { name: string; appointments: number }[];
  cancellationRate: number;
  noShowRate: number;
  totalRevenue: number;
  totalPatients: number;
  statusDistribution: { status: string; count: number }[];
}
