import { Doctor, Appointment, Patient, AnalyticsData, TimeSlot } from '@/types/clinic';

export const doctors: Doctor[] = [
  {
    id: 'd1',
    name: 'Dr. Priya Sharma',
    specialty: 'General Physician',
    workingHours: { start: '09:00', end: '17:00' },
    breakTime: { start: '13:00', end: '14:00' },
    consultationDuration: 15,
  },
  {
    id: 'd2',
    name: 'Dr. Rajesh Patel',
    specialty: 'Cardiologist',
    workingHours: { start: '10:00', end: '18:00' },
    breakTime: { start: '13:30', end: '14:30' },
    consultationDuration: 20,
  },
  {
    id: 'd3',
    name: 'Dr. Anita Desai',
    specialty: 'Dermatologist',
    workingHours: { start: '08:00', end: '15:00' },
    breakTime: { start: '12:00', end: '12:30' },
    consultationDuration: 15,
  },
];

const today = new Date().toISOString().split('T')[0];
const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

export const initialAppointments: Appointment[] = [
  { id: 'a1', patientName: 'Amit Kumar', patientPhone: '9876543210', doctorId: 'd1', doctorName: 'Dr. Priya Sharma', date: today, time: '09:00', symptoms: 'Fever, cough', status: 'scheduled', noShowProbability: 0.12, createdAt: yesterday },
  { id: 'a2', patientName: 'Sneha Reddy', patientPhone: '9876543211', doctorId: 'd1', doctorName: 'Dr. Priya Sharma', date: today, time: '09:15', symptoms: 'Headache', status: 'scheduled', noShowProbability: 0.05, createdAt: yesterday },
  { id: 'a3', patientName: 'Rahul Verma', patientPhone: '9876543212', doctorId: 'd2', doctorName: 'Dr. Rajesh Patel', date: today, time: '10:00', symptoms: 'Chest pain', status: 'completed', noShowProbability: 0.08, createdAt: yesterday },
  { id: 'a4', patientName: 'Meera Nair', patientPhone: '9876543213', doctorId: 'd2', doctorName: 'Dr. Rajesh Patel', date: today, time: '10:20', symptoms: 'Blood pressure', status: 'scheduled', noShowProbability: 0.45, createdAt: yesterday },
  { id: 'a5', patientName: 'Vikram Singh', patientPhone: '9876543214', doctorId: 'd3', doctorName: 'Dr. Anita Desai', date: today, time: '08:00', symptoms: 'Skin rash', status: 'cancelled', noShowProbability: 0.3, createdAt: yesterday },
  { id: 'a6', patientName: 'Pooja Gupta', patientPhone: '9876543215', doctorId: 'd1', doctorName: 'Dr. Priya Sharma', date: today, time: '10:00', symptoms: 'Joint pain', status: 'scheduled', noShowProbability: 0.72, createdAt: yesterday },
  { id: 'a7', patientName: 'Arjun Mehta', patientPhone: '9876543216', doctorId: 'd3', doctorName: 'Dr. Anita Desai', date: today, time: '08:30', symptoms: 'Acne', status: 'no-show', noShowProbability: 0.65, createdAt: yesterday },
];

export const patients: Patient[] = [
  { id: 'p1', name: 'Amit Kumar', phone: '9876543210', email: 'amit@email.com', history: ['Fever', 'Cold'], noShowCount: 0, totalAppointments: 5 },
  { id: 'p2', name: 'Sneha Reddy', phone: '9876543211', email: 'sneha@email.com', history: ['Migraine'], noShowCount: 1, totalAppointments: 8 },
  { id: 'p3', name: 'Rahul Verma', phone: '9876543212', history: ['Heart checkup'], noShowCount: 0, totalAppointments: 3 },
  { id: 'p4', name: 'Pooja Gupta', phone: '9876543215', history: ['Arthritis'], noShowCount: 3, totalAppointments: 6 },
];

export function generateTimeSlots(doctor: Doctor, date: string, existingAppointments: Appointment[]): TimeSlot[] {
  const slots: TimeSlot[] = [];
  const [startH, startM] = doctor.workingHours.start.split(':').map(Number);
  const [endH, endM] = doctor.workingHours.end.split(':').map(Number);
  const [breakStartH, breakStartM] = doctor.breakTime.start.split(':').map(Number);
  const [breakEndH, breakEndM] = doctor.breakTime.end.split(':').map(Number);

  const bookedTimes = existingAppointments
    .filter(a => a.doctorId === doctor.id && a.date === date && a.status !== 'cancelled')
    .map(a => a.time);

  let current = startH * 60 + startM;
  const end = endH * 60 + endM;
  const breakStart = breakStartH * 60 + breakStartM;
  const breakEnd = breakEndH * 60 + breakEndM;

  while (current < end) {
    if (current >= breakStart && current < breakEnd) {
      current += doctor.consultationDuration;
      continue;
    }
    const h = Math.floor(current / 60).toString().padStart(2, '0');
    const m = (current % 60).toString().padStart(2, '0');
    const time = `${h}:${m}`;
    slots.push({ time, available: !bookedTimes.includes(time) });
    current += doctor.consultationDuration;
  }
  return slots;
}

export function getAnalyticsData(appointments: Appointment[]): AnalyticsData {
  const last7days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(Date.now() - (6 - i) * 86400000);
    return d.toISOString().split('T')[0];
  });

  const dailyAppointments = last7days.map(date => ({
    date: new Date(date).toLocaleDateString('en', { weekday: 'short' }),
    count: appointments.filter(a => a.date === date).length || Math.floor(Math.random() * 12 + 3),
  }));

  const doctorWorkload = doctors.map(d => ({
    name: d.name.replace('Dr. ', ''),
    appointments: appointments.filter(a => a.doctorId === d.id).length,
  }));

  const total = appointments.length || 1;
  const cancelled = appointments.filter(a => a.status === 'cancelled').length;
  const noShows = appointments.filter(a => a.status === 'no-show').length;

  const statusDistribution = [
    { status: 'Scheduled', count: appointments.filter(a => a.status === 'scheduled').length },
    { status: 'Completed', count: appointments.filter(a => a.status === 'completed').length },
    { status: 'Cancelled', count: cancelled },
    { status: 'No-show', count: noShows },
  ];

  return {
    dailyAppointments,
    doctorWorkload,
    cancellationRate: Math.round((cancelled / total) * 100),
    noShowRate: Math.round((noShows / total) * 100),
    totalRevenue: appointments.filter(a => a.status === 'completed').length * 500,
    totalPatients: new Set(appointments.map(a => a.patientPhone)).size,
    statusDistribution,
  };
}

export function predictNoShow(patient?: Patient): number {
  if (!patient) return Math.random() * 0.3 + 0.05;
  const noShowRate = patient.totalAppointments > 0 ? patient.noShowCount / patient.totalAppointments : 0;
  const dayFactor = [0.1, 0.05, 0.05, 0.08, 0.12, 0.15, 0.2][new Date().getDay()];
  return Math.min(Math.round((noShowRate * 0.6 + dayFactor * 0.4) * 100) / 100, 1);
}
